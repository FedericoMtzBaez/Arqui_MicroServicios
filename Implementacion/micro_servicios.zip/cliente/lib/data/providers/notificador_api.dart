// -------------------------------------------------------------------------
//  Archivo: notifier_api.dart
//  Capitulo: Estilo Microservicios
//  Autor(es): Perla Velasco & Yonathan Mtz. & Jorge Solís
//  Version: 3.0.0 Febrero 2022
//  Descripción:
//
//    Ésta clase define la conexión con un Microservicio externo.
//
//    A continuación se describen los métodos que se implementaron en ésta
//    clase:
//
//                                       Métodos:
//    +------------------------+--------------------------+--------------------+
//    |         Nombre         |        Parámetros        |        Función     |
//    +------------------------+--------------------------+--------------------+
//    |   sendNotification()   | - message: mensaje a     | - Realiza el       |
//    |                        |   notificar              |   envió de la      |
//    |                        |                          |   notificación a   |
//    |                        |                          |   través del       |
//    |                        |                          |   Microservicio de |
//    |                        |                          |   notificaciones   |
//    +------------------------+--------------------------+--------------------+
//
//
// -------------------------------------------------------------------------
//  Archivo: notifier_api.dart
// -------------------------------------------------------------------------
import 'dart:convert';
import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'package:http/http.dart' as http;

class NotificadorAPI {
  final String gatewayHost = dotenv.env['GATEWAY_HOST'] ?? "localhost";
  final String gatewayPort = dotenv.env['GATEWAY_PORT'] ?? "8001";

  // Headers correctos para enviar JSON
  final Map<String, String> headers = {
    // Agregamos '; charset=UTF-8' para soportar tildes y eñes sin romper el JSON
    "Content-Type": "application/json; charset=UTF-8",
    "Accept": "application/json"
  };

  // MODIFICACIÓN: Ahora recibe también el mapa de datos del cliente
  Future<http.Response> enviarNotificacionTelegram(String message, Map<String, dynamic> clientData) async {

    // Construimos el JSON idéntico al de Postman
    Map<String, dynamic> requestBody = {
      "message": message,
      "client": clientData
    };

    String endpoint = "/telegram";
    // Construcción de la URL (http://localhost:8080/notificador/telegram)
    var uri = Uri.http("$gatewayHost:$gatewayPort", endpoint);
    
    print("JSON a enviar: ${jsonEncode(requestBody)}");
    var response = await http.post(
      uri,
      headers: headers, // Usamos los headers definidos arriba
      body: jsonEncode(requestBody),
    );

    return response;
  }
}