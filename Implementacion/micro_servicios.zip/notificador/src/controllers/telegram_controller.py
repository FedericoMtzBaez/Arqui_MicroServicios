#!/usr/bin/env python
# -*- coding: utf-8 -*-
#-------------------------------------------------------------------------
# Archivo: telegram_controller.py
# Capitulo: Estilo Microservicios
# Autor(es): Perla Velasco & Yonathan Mtz. & Jorge Solís
# Version: 3.0.0 Febrero 2022
# Descripción:
#
#   Ésta clase define el controlador del microservicio API. 
#   Implementa la funcionalidad y lógica de negocio del Microservicio.
#
#-------------------------------------------------------------------------
from flask import request, jsonify
import requests
import configparser
import os
import json
import sys

class TelegramController:

    @staticmethod
    def send_message():
        # 1. Validación del JSON de entrada (ROBUSTA)
        # force=True: Intenta parsear JSON ignorando el Content-Type
        # silent=True: Devuelve None en lugar de lanzar error si falla
        data = request.get_json(force=True, silent=True)

        if data is None:
            print(f"[ERROR] No se pudo leer el cuerpo JSON. Data raw: {request.data}", file=sys.stderr)
            return jsonify({"msg": "Invalid or missing JSON payload"}), 400

        if not data.get("message", "").strip():
            print(f"[ERROR] JSON recibido incompleto (falta 'message'): {data}", file=sys.stderr)
            return jsonify({"msg": "Missing or empty 'message'"}), 400

        message = data["message"]
        client_info = data.get("client")

        # 2. Carga de Configuración (settings.ini)
        config = configparser.ConfigParser()
        # Calculamos la ruta absoluta al settings.ini
        base_dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.realpath(__file__))))
        config_path = os.path.join(base_dir, 'settings.ini')

        read_files = config.read(config_path)
        if not read_files:
            print(f"[ERROR] No se encontró el archivo settings.ini en: {config_path}", file=sys.stderr)
            return jsonify({"msg": f"Configuration file missing at {config_path}"}), 500

        try:
            token = config['TELEGRAM']['TOKEN']
            chat_id = config['TELEGRAM']['CHAT_ID']
        except KeyError as e:
            print(f"[ERROR] Falta la configuración {str(e)} en settings.ini", file=sys.stderr)
            return jsonify({"msg": "Telegram configuration missing keys"}), 500

        # 3. Enviar mensaje a Telegram
        try:
            print(f"[INFO] Enviando mensaje a Chat ID: {chat_id}...", file=sys.stdout)
            text_response = requests.post(
                f"https://api.telegram.org/bot{token}/sendMessage",
                json={"chat_id": chat_id, "text": message},
                timeout=10
            )
        except requests.exceptions.RequestException as e:
            print(f"[ERROR] Error de conexión con Telegram: {e}", file=sys.stderr)
            return jsonify({"msg": "Connection to Telegram failed", "error": str(e)}), 500

        if text_response.status_code != 200:
            error_details = text_response.text
            print(f"[ERROR] Telegram API respondió con error: {error_details}", file=sys.stderr)
            return jsonify({
                "msg": "Telegram API Error",
                "status_code": text_response.status_code,
                "telegram_response": error_details
            }), 500

        print("[SUCCESS] Mensaje enviado correctamente.", file=sys.stdout)

        # 4. Procesar PDF si existe client_info
        if not client_info:
            return jsonify({"msg": "Message sent"}), 200

        try:
            # Descargar PDF del servicio reporteador
            # NOTA: Asegúrate de que 'tyk-gateway' sea accesible desde este contenedor
            # Si estás probando localmente sin gateway, cambia la URL a donde corra el reporteador
            print("[INFO] Solicitando PDF al reporteador...", file=sys.stdout)

            # Usamos tyk-gateway puerto 8080 por defecto.
            # Si estás usando puertos directos, cambia esto al puerto del reporteador (ej. 8002)
            # El servicio 'reporteador' escucha en el puerto 8002
            report_url = "http://reporteador:8002/policy.pdf"

            pdf_response = requests.get(
                report_url,
                params={"data": json.dumps(client_info)},
                timeout=10
            )

            if pdf_response.status_code != 200:
                error_msg = f"Reporteador error ({pdf_response.status_code}): {pdf_response.text}"
                raise Exception(error_msg)

            # Enviar PDF a Telegram
            print("[INFO] Enviando documento PDF a Telegram...", file=sys.stdout)

            # Usamos 'numero_poliza' si existe, si no 'policy' (para compatibilidad con Flutter)
            poliza_id = client_info.get('numero_poliza') or client_info.get('policy') or 'cliente'

            doc_response = requests.post(
                f"https://api.telegram.org/bot{token}/sendDocument",
                files={
                    "document": (
                        f"poliza_{poliza_id}.pdf",
                        pdf_response.content,
                        "application/pdf"
                    )
                },
                data={"chat_id": chat_id},
                timeout=20
            )

            if doc_response.status_code != 200:
                raise Exception(f"Telegram doc error: {doc_response.text}")

            print("[SUCCESS] PDF enviado correctamente.", file=sys.stdout)
            return jsonify({"msg": "Message and PDF sent"}), 200

        except Exception as e:
            print(f"[WARNING] Mensaje enviado pero falló el PDF: {str(e)}", file=sys.stderr)
            return jsonify({
                "msg": "Message sent but PDF failed",
                "error": str(e)
            }), 202

    @staticmethod
    def health_check():
        return jsonify({"status": "ok"}), 200